// src/pages/agent/AgentApplications.tsx
import React, { useState, useEffect } from 'react';
import { Card } from '../../components/ui/Card';
import { agentApi } from '../../features/agent/api/agentApi';
import { CreateApplicationForm } from '../../features/agent/components/CreateApplicationForm';
import { ApplicationList } from '../../features/agent/components/ApplicationList';
import type { Application } from '../../features/agent/types';

export const AgentApplications = () => {
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState(false);

  const services = [
    { _id: '1', name: 'Study Abroad Consultation' },
    { _id: '2', name: 'Visa Application Assistance' }
  ];

  useEffect(() => {
    fetchApplications();
  }, []);

  const fetchApplications = async () => {
    try {
      const data = await agentApi.getApplications();
      setApplications(data);
    } catch (err) {
      setError('Failed to load applications');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateApplication = async (data: { visitorId: string; serviceId: string }) => {
    try {
      setIsCreating(true);
      await agentApi.createApplication(data);
      await fetchApplications();
    } catch (err) {
      console.error('Failed to create application:', err);
    } finally {
      setIsCreating(false);
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div className="text-red-600">{error}</div>;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Applications</h1>
      
      <Card className="p-6">
        <CreateApplicationForm
          onSubmit={handleCreateApplication}
          services={services}
          isLoading={isCreating}
        />
      </Card>

      <ApplicationList applications={applications} />
    </div>
  );
};
