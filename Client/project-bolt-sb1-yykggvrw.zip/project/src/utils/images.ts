export const getDefaultNewsImage = () => 
  'https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&q=80';

export const getDefaultUniversityImage = () =>
  'https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&q=80';

export const getDefaultCourseImage = () =>
  'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&q=80';