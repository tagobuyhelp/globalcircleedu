export const quickStats = [
  { label: 'Universities', value: '500+' },
  { label: 'Courses', value: '1,000+' },
  { label: 'Students', value: '50,000+' },
  { label: 'Countries', value: '50+' }
] as const;