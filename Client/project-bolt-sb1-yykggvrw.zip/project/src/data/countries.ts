export const countries = [
  'United States',
  'United Kingdom',
  'Canada',
  'Australia',
  'New Zealand',
  'Germany',
  'France',
  'Ireland',
  'Netherlands',
  'Singapore',
  'Japan',
  'South Korea',
  'India',
  'United Arab Emirates',
  'Malaysia'
] as const;