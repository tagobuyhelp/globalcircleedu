export interface Degree {
  _id: string;
  name: string;
  abbreviation?: string;
  description?: string;
  createdAt: string;
  updatedAt: string;
}