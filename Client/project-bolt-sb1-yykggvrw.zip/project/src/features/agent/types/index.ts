// src/features/agent/types/index.ts
export type PaymentMethod = 'bank_transfer' | 'paypal' | 'stripe';

export interface Application {
  _id: string;
  visitorId: {
    _id: string;
    name: string;
    email: string;
  };
  serviceId: {
    _id: string;
    name: string;
  };
  status: 'Pending' | 'Approved' | 'Rejected';
  paymentStatus: 'Pending' | 'Completed';
  commissionAmount: number;
  createdAt: string;
}

export interface AgentStats {
  totalApplications: number;
  approvedApplications: number;
  totalCommission: number;
  totalEarned: number;
  availableBalance: number;
}

export interface WithdrawalRequest {
  _id: string;
  amount: number;
  status: 'Pending' | 'Approved' | 'Declined';
  requestedAt: string;
}

export interface PaymentDetails {
  bankName?: string;
  accountNumber?: string;
  accountHolderName?: string;
  paypalEmail?: string;
  stripeAccountId?: string;
}
