// src/pages/agent/AgentDashboard.tsx
import React, { useState, useEffect } from 'react';
import { agentApi } from '../../features/agent/api/agentApi';
import { StatsOverview } from '../../features/agent/components/StatsOverview';
import type { AgentStats } from '../../features/agent/types';

export const AgentDashboard = () => {
  const [stats, setStats] = useState<AgentStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const data = await agentApi.getStats();
        setStats(data);
      } catch (err) {
        setError('Failed to load stats');
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div className="text-red-600">{error}</div>;
  if (!stats) return null;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Agent Dashboard</h1>
      <StatsOverview stats={stats} />
    </div>
  );
};
