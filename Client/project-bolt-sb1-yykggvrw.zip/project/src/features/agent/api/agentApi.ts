// src/features/agent/api/agentApi.ts
import axios from '../../../lib/axios';
import type { Application, AgentStats, WithdrawalRequest, PaymentMethod } from '../types';

export const agentApi = {
  // Applications
  createApplication: async (data: { visitorId: string; serviceId: string }) => {
    const { data: response } = await axios.post('/agent/applications', data);
    return response.application;
  },

  getApplications: async () => {
    const { data } = await axios.get('/agent/applications');
    return data.applications;
  },

  getApplicationDetails: async (id: string) => {
    const { data } = await axios.get(`/agent/applications/${id}`);
    return data.application;
  },

  updateApplication: async (id: string, status: string) => {
    const { data } = await axios.put(`/agent/applications/${id}`, { status });
    return data.application;
  },

  // Stats and Withdrawals
  getStats: async () => {
    const { data } = await axios.get('/agent/stats');
    return data.stats;
  },

  requestWithdrawal: async (amount: number) => {
    const { data } = await axios.post('/agent/withdraw', { amount });
    return data.withdrawalRequest;
  },

  getWithdrawalRequests: async () => {
    const { data } = await axios.get('/agent/withdrawals');
    return data.withdrawalRequests;
  },

  updatePaymentMethod: async (updates: {
    paymentMethod: PaymentMethod;
    paymentDetails: Record<string, string>;
  }) => {
    const { data } = await axios.put('/agent/payment-method', updates);
    return data.agent;
  }
};
